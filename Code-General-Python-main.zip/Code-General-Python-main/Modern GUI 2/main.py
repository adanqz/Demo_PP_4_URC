from formularios.form_maestro_design import FormularioMaestroDesign

app = FormularioMaestroDesign()
app.mainloop()