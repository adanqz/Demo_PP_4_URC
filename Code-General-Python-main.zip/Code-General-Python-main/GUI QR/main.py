from formulario.form_maestra import FormMestro

app = FormMestro()
app.mainloop()