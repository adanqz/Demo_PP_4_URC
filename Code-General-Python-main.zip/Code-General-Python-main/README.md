# mini_proyectos
Encontraras pequeños ejemplos de código de Python
